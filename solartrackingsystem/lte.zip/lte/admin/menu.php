<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <!-- search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview">
              <a href="#">
                <i class="glyphicon glyphicon-file"></i> <span>Berita</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="index.php?page=berita"><i class="glyphicon glyphicon-pencil"></i> Input Berita</a></li>
                <li><a href="index.php?page=list_berita"><i class="glyphicon glyphicon-list active"></i> List Berita</a></li>
              </ul>
            </li> 
			<li class="treeview">
              <a href="#">
                <i class="glyphicon glyphicon-file"></i><span>Agenda</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="index.php?page=agenda"><i class="glyphicon glyphicon-pencil"></i> Input Agenda</a></li>
                <li><a href="index.php?page=list_agenda"><i class="glyphicon glyphicon-list"></i> List Agenda</a></li>
              </ul>
            </li>
			<li><a href="logout.php"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>
          </ul>
        </section>
        <!-- /.sidebar -->
</aside>